<p align="center">    
  <img src="https://i.imgur.com/LyHic3i.gif" />    
</p>    
    
<div align="center">     
  <a href="https://git.io/typing-svg">     
    <img src="https://readme-typing-svg.demolab.com?font=Algerian&size=60&pause=1000&color=df2e46&center=true&width=910&height=100&lines=PEACE-HUB;Multi+Device+Whatsapp+Bot;Coded+By+PEACEMAKER" alt="Typing SVG" />    
  </a>     
</div>     
    
<p align="center">    
  <img src="https://i.imgur.com/LyHic3i.gif" />    
</p>    
    
<p align="center">    
  <img src="https://files.catbox.moe/5m0i6t.jpg" />    
</p>    
    
<!-- 📊 STATS & HERO ANIMATION (Updated Colors) -->    
<div align="center">    
    
  <p align="center">    
    <img src="https://i.imgur.com/LyHic3i.gif" alt="Authentication Flow Preview" />    
  </p>    
    
  <p align="center">    
    <img src="https://i.imgur.com/LyHic3i.gif" width="65%" />    
  </p>    
   
  <div align="center">    
    <img src="https://github.com/Devpeacemaker/PEACE-MD/blob/main/assets/techwave.gif?raw=true" width="80%"/>    
  </div>    
    <div align="center" style="margin-top: 30px;">
  <a href="https://peacehubvercel.vercel.app/" target="_blank" style="display: inline-block; width: 90%; max-width: 400px;">
    <img src="https://img.shields.io/badge/🚀 Deploy PEACE HUB Now-7A3E9D?style=for-the-badge&logo=vercel&logoColor=white" 
         alt="Deploy PEACE HUB Now" 
         style="width: 100%; height: auto; border-radius: 8px;" />
  </a>
</div>
